alter table big_bear.items add column container_code text check (char_length(container_code)<=80);
create or replace function public.bb_catalog() returns jsonb language plpgsql security invoker set search_path='' as $$ begin
 if not big_bear.is_member() then raise exception 'Brak dostępu do magazynu Big Bear Studio.'; end if;
 return jsonb_build_object('categories',(select coalesce(jsonb_agg(c order by c.name),'[]') from big_bear.categories c),'items',(select coalesce(jsonb_agg(x order by x.updated_at desc),'[]') from (select i.id,i.code,i.name,i.description,i.category_id,i.quantity,i.condition,i.tags,i.container_code,i.version,i.updated_at,(select coalesce(jsonb_agg(p order by p.created_at),'[]') from big_bear.photos p where p.item_id=i.id) as photos from big_bear.items i where not i.archived) x)); end $$;
create or replace function public.bb_save_item(p_data jsonb) returns uuid language plpgsql security invoker set search_path='' as $$
 declare v_id uuid; begin
 if not big_bear.is_member() then raise exception 'Brak dostępu.'; end if;
 if nullif(p_data->>'id','') is null then
 insert into big_bear.items(name,description,category_id,quantity,condition,tags,container_code) values(trim(p_data->>'name'),coalesce(p_data->>'description',''),nullif(p_data->>'category_id','')::uuid,(p_data->>'quantity')::integer,coalesce(p_data->>'condition','good'),coalesce(p_data->>'tags',''),nullif(trim(p_data->>'container_code'),'')) returning id into v_id;
 else
 v_id:=(p_data->>'id')::uuid;
 perform 1 from big_bear.items where id=v_id and not archived for update;
 update big_bear.items set name=trim(p_data->>'name'),description=coalesce(p_data->>'description',''),category_id=nullif(p_data->>'category_id','')::uuid,quantity=(p_data->>'quantity')::integer,condition=p_data->>'condition',tags=coalesce(p_data->>'tags',''),container_code=case when p_data ? 'container_code' then nullif(trim(p_data->>'container_code'),'') else container_code end,updated_at=now(),version=version+1 where id=v_id and not archived and version=(p_data->>'version')::integer;
 if not found then raise exception 'Rekwizyt zmienił się w międzyczasie. Odśwież katalog i spróbuj ponownie.'; end if;
 end if;
 insert into big_bear.activity(item_id,description) values(v_id,case when nullif(p_data->>'id','') is null then 'Dodano rekwizyt' else 'Zaktualizowano dane i stan magazynowy' end);
 return v_id; end $$;
