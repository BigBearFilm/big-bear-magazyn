import { createClient } from '@supabase/supabase-js';
export const supabase = createClient('https://ltyafffwvirfvmjrkzwj.supabase.co','sb_publishable_iFo9WnFVlvo85S5_DpzKkQ_s8oSS05E',{auth:{storageKey:'big-bear-studio-auth',persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
export type Photo={id:string;item_id:string;path:string;url?:string};
export type Item={id:string;code:number;name:string;description:string;category_id:string|null;quantity:number;condition:string;tags:string;photos:Photo[];version:number;updated_at:string};
export type Category={id:string;name:string};
export type Catalog={items:Item[];categories:Category[]};
export async function rpc<T=unknown>(name:string,args:Record<string,unknown>={}){const {data,error}=await supabase.rpc(name,args);if(error)throw new Error(error.message);return data as T;}
export async function catalog(){const data=await rpc<Catalog>('bb_catalog');const paths=data.items.flatMap(i=>i.photos.map(p=>p.path));if(paths.length){const {data:urls,error}=await supabase.storage.from('big-bear-photos').createSignedUrls(paths,3600);if(error)throw new Error('Nie udało się pobrać zdjęć. '+error.message);const map=new Map(urls.map(p=>[p.path,p.signedUrl]));data.items.forEach(i=>i.photos.forEach(p=>p.url=map.get(p.path)||undefined));}return data;}
export const code=(i:Item)=>`BB-${String(i.code).padStart(5,'0')}`;
export const conditionName:Record<string,string>={good:'Dobry',worn:'Ślady użycia',repair:'Do naprawy'};
export function message(e:unknown){return e instanceof Error?e.message:'Nie udało się wykonać operacji. Spróbuj ponownie.';}
export async function upload(itemId:string,files:File[]){for(const file of files){let blob:Blob=file;
 if(file.size>10*1024*1024)throw new Error('Maksymalny rozmiar zdjęcia to 10 MB.');
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Wybierz zdjęcie JPG, PNG lub WebP.');
 const bitmap=await createImageBitmap(file);try{const ratio=Math.min(1,1800/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);canvas.getContext('2d')!.drawImage(bitmap,0,0,canvas.width,canvas.height);blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Nie można przygotować zdjęcia.')),'image/webp',0.85));}finally{bitmap.close();}
 const path=`${itemId}/${crypto.randomUUID()}.webp`;const {error}=await supabase.storage.from('big-bear-photos').upload(path,blob,{contentType:'image/webp',upsert:false});if(error)throw new Error(error.message);
 try{await rpc('bb_photo',{p_item:itemId,p_path:path});}catch(e){await supabase.storage.from('big-bear-photos').remove([path]);throw e;}
}}
